package br.edu.ufabc.imccalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView pesoText;
    TextView alturaText;
    TextView imcText;
    TextView imcStatusText;
    SeekBar pesoSeek;
    SeekBar alturaSeek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        bindComponents();
        bindSeekbarHandlers();
        init();
    }

    private void bindComponents() {
        pesoText = findViewById(R.id.peso_text);
        alturaText = findViewById(R.id.altura_text);
        imcText = findViewById(R.id.imc_text);
        imcStatusText = findViewById(R.id.imc_status_text);
        pesoSeek = findViewById(R.id.peso_seek);
        alturaSeek = findViewById(R.id.altura_seek);
    }

    private void init() {
        alturaSeek.setProgress(170);
        pesoSeek.setProgress(60);
    }

    public void updateImc() {
        double peso = pesoSeek.getProgress();
        double altura = alturaSeek.getProgress() / 100.0;

        double imc = 0.0;

        if (altura > 0.0)
            imc = peso / (altura * altura);

        imcText.setText(String.format("%.2f", imc));
    }

    public void updatePeso(int progress) {
        pesoText.setText(progress + " kg");
        updateImc();
    }

    public void updateAltura(int progress) {
        alturaText.setText(progress / 100.0 + " m");
        updateImc();
    }

    private void bindSeekbarHandlers() {
        pesoSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updatePeso(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        alturaSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateAltura(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }


}
