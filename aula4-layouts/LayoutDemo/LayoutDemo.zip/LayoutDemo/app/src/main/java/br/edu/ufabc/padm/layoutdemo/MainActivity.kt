package br.edu.ufabc.padm.layoutdemo

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner


class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        populateLayoutChoices()
    }

    private fun populateLayoutChoices() {
        val spinner = findViewById<View>(R.id.layout_chooser) as Spinner
        val adapter = ArrayAdapter.createFromResource(this,
                R.array.layout_array, android.R.layout.simple_spinner_item)

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.onItemSelectedListener = this
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId


        return if (id == R.id.action_settings) {
            true
        } else super.onOptionsItemSelected(item)

    }

    override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
        val choice = parent.getItemAtPosition(position).toString()
        var intent: Intent? = null

        if (choice == "LinearLayout")
            intent = Intent(this, LinearLayoutDemo::class.java)
        else if (choice == "RelativeLayout")
            intent = Intent(this, RelativeLayoutDemo::class.java)
        else if (choice == "ListView")
            intent = Intent(this, ListViewDemo::class.java)
        else if (choice == "GridView")
            intent = Intent(this, GridViewDemo::class.java)

        intent?.let { startActivity(it) } ?: Log.e("MainActivity", "No option has been selected")
    }

    override fun onNothingSelected(parent: AdapterView<*>) {
        Log.d("TESTING", "no item has been selected")
    }
}
