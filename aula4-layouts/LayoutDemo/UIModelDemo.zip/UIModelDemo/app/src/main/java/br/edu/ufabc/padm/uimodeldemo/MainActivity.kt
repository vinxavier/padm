package br.edu.ufabc.padm.uimodeldemo

import android.content.res.Configuration
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val orientation = resources.configuration.orientation

        super.onCreate(savedInstanceState)
        // inject a landscape (declarative) layout
        if (orientation == Configuration.ORIENTATION_LANDSCAPE)
            setContentView(R.layout.activity_main)
        else if (orientation == Configuration.ORIENTATION_PORTRAIT)
            setContentView(createLayout())// inject a portrait (imperative) layout
    }

    /**
     * Programmatically create a portrait a layout
     * @return the layout as a ViewGroup
     */
    private fun createLayout(): ViewGroup {
        val root = RelativeLayout(this)
        val params = RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT)
        val text = TextView(this)

        root.layoutParams = params
        text.setText(R.string.portrait_message)
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 40f)
        root.addView(text)

        return root
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId


        return if (id == R.id.action_settings) {
            true
        } else super.onOptionsItemSelected(item)

    }
}
