package br.edu.ufabc.cronometro

import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView

import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var timeElapsedText: TextView
    private lateinit var timeElapsed: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()

        bindControls()
        runTimer()
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        timeElapsed = savedInstanceState.getLong("timeElapsed")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong("timeElapsed", timeElapsed)
    }

    private fun bindControls() {
        timeElapsedText = findViewById(R.id.time_elapsed)
    }

    private fun reset() {
        timeElapsed = 0
    }

    private fun updateTime() {
        val hours = timeElapsed / 3600
        val minutes = timeElapsed % 3600 / 60
        val seconds = timeElapsed % 60

        timeElapsedText.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds))
    }

    private fun runTimer() {
        val handler = Handler()

        handler.post(object : Runnable {
            override fun run() {
                timeElapsed++
                updateTime()
                handler.postDelayed(this, TIMER_SPEED)
            }
        })
    }

    companion object {

        private val TIMER_SPEED: Long = 1000
    }
}
